class Station {
  final int id;
  final String name;
  final String line;
  final int order;
  final bool isInterchange;
  final double latitude;
  final double longitude;

  Station({
    required this.id,
    required this.name,
    required this.line,
    required this.order,
    required this.isInterchange,
    required this.latitude,
    required this.longitude,
  });

  factory Station.fromJson(Map<String, dynamic> json) {
    double parseDouble(dynamic value) {
      if (value == null) return 0.0;
      if (value is double) return value;
      if (value is int) return value.toDouble();
      if (value is String) return double.tryParse(value) ?? 0.0;
      return 0.0;
    }

    return Station(
      id: json['id'] is int ? json['id'] : int.tryParse(json['id'].toString()) ?? 0,
      name: (json['name'] ?? '').toString().trim(),
      line: (json['line'] ?? json['line_id'] ?? '').toString().trim(),
      order: json['station_order'] is int
          ? json['station_order']
          : int.tryParse(json['station_order']?.toString() ?? '') ?? 0,
      isInterchange: json['is_interchange'] is bool
          ? json['is_interchange']
          : (json['is_interchange'] == null ? false : json['is_interchange'].toString().toLowerCase() == 'true'),
      latitude: parseDouble(json['latitude']),
      longitude: parseDouble(json['longitude']),
    );
  }

  @override
  String toString() => '$name (Line $line) [$latitude, $longitude]';
}