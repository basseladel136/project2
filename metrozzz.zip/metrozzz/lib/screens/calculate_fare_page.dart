import 'package:flutter/material.dart';
import '../models/station.dart';
import '../services/station_service.dart';
import 'metro_lines_page.dart';

class CalculateFarePage extends StatefulWidget {
  @override
  State<CalculateFarePage> createState() => _CalculateFarePageState();
}

class _CalculateFarePageState extends State<CalculateFarePage> {
  List<Station> stations = [];
  int? startStationId;
  int? endStationId;
  int numPeople = 1;
  int numStations = 0;
  int totalTime = 0;
  double fare = 0;
  bool calculated = false;
  bool isLoading = false;

  int _selectedIndex = 1; // for Ticket Price tab
  final Color _navy = Color(0xFF1A1749);


  @override
  void initState() {
    super.initState();
    _loadStations();
  }

  Future<void> _loadStations() async {
    setState(() => isLoading = true);
    try {
      final data = await StationService().fetchStations();
      setState(() {
        stations = data;
        isLoading = false;
      });
    } catch (e) {
      setState(() => isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load stations: $e')),
      );
    }
  }

  Future<void> _calculate() async {
    if (startStationId == null || endStationId == null || startStationId == endStationId) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please select different start and end stations')),
      );
      return;
    }

    setState(() {
      isLoading = true;
      calculated = false;
    });

    try {
      final journey = await StationService().fetchJourneyStationsById(startStationId!, endStationId!);
      if (journey.isEmpty) {
        setState(() {
          isLoading = false;
          calculated = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No journey found for selected stations.')),
        );
        return;
      }

      numStations = journey.length;
      totalTime = numStations * 2;

      if (numStations <= 9)
        fare = 8.0;
      else if (numStations <= 16)
        fare = 10.0;
      else if (numStations <= 23)
        fare = 15.0;
      else
        fare = 20.0;

      setState(() {
        calculated = true;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        calculated = false;
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error calculating fare: $e')),
      );
    }
  }

  void _onBottomNavTap(int index) {
    setState(() => _selectedIndex = index);
    switch (index) {
      case 0: // Settings
        Navigator.pushNamed(context, '/settings');
        break;
      case 1: // Ticket Price (self page)
        break;
      case 2: // Metro Lines
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => MetroLinesPage()),
        );
        break;
      case 3: // Home Page
        Navigator.pushNamed(context, '/homePage');
        break;
    }
  }
  Color _getLineColor(String line) {
    switch (line) {
      case '1':
        return Colors.red;
      case '2':
        return Colors.blue;
      case '3':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = Theme.of(context).textTheme.bodyLarge?.color ?? (isDark ? Colors.white : Colors.black);
    final cardColor = Theme.of(context).cardColor;
    final dividerColor = isDark ? Colors.white12 : Colors.grey[300];

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : ListView(
        padding: EdgeInsets.zero,
        children: [
          SizedBox(height: 18),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Container(
              padding: EdgeInsets.all(19),
              decoration: BoxDecoration(
                color: cardColor,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.help_outline, color: textColor, size: 26),
                      SizedBox(width: 6),
                      Text(
                        "Calculate the price of your trip",
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: textColor),
                      ),
                    ],
                  ),
                  SizedBox(height: 4),
                  Padding(
                    padding: EdgeInsets.only(left: 2),
                    child: Text(
                      "Choose the station and number of people to see the fare",
                      style: TextStyle(color: textColor.withOpacity(0.7), fontSize: 13, fontWeight: FontWeight.w400),
                    ),
                  ),
                  SizedBox(height: 18),

                  // From dropdown (station ID)
                  // From dropdown (station ID)
                  DropdownButtonFormField<int>(
                    value: startStationId,
                    dropdownColor: cardColor,
                    decoration: _inputDecoration("From", isDark),
                    items: stations.map((s) => DropdownMenuItem<int>(
                      value: s.id,
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 10,
                            backgroundColor: _getLineColor(s.line),
                            child: Text(
                              s.line,
                              style: TextStyle(color: Colors.white, fontSize: 12),
                            ),
                          ),
                          SizedBox(width: 8),
                          Text(s.name, style: TextStyle(color: textColor)),
                        ],
                      ),
                    )).toList(),
                    style: TextStyle(color: textColor),
                    onChanged: (value) => setState(() {
                      startStationId = value;
                      calculated = false;
                    }),
                  ),
                  SizedBox(height: 12),

                  // To dropdown (station ID)
                  // To dropdown (station ID)
                  DropdownButtonFormField<int>(
                    value: endStationId,
                    dropdownColor: cardColor,
                    decoration: _inputDecoration("To", isDark),
                    items: stations.map((s) => DropdownMenuItem<int>(
                      value: s.id,
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 10,
                            backgroundColor: _getLineColor(s.line),
                            child: Text(
                              s.line,
                              style: TextStyle(color: Colors.white, fontSize: 12),
                            ),
                          ),
                          SizedBox(width: 8),
                          Text(s.name, style: TextStyle(color: textColor)),
                        ],
                      ),
                    )).toList(),
                    style: TextStyle(color: textColor),
                    onChanged: (value) => setState(() {
                      endStationId = value;
                      calculated = false;
                    }),
                  ),
                  SizedBox(height: 12),

                  // Number of people dropdown
                  DropdownButtonFormField<int>(
                    value: numPeople,
                    dropdownColor: cardColor,
                    decoration: _inputDecoration("No of people", isDark),
                    items: List.generate(10, (i) => i + 1)
                        .map(
                          (n) => DropdownMenuItem<int>(
                        value: n,
                        child: Text(n.toString(), style: TextStyle(color: textColor)),
                      ),
                    )
                        .toList(),
                    style: TextStyle(color: textColor),
                    onChanged: (v) => setState(() {
                      numPeople = v ?? 1;
                      calculated = false;
                    }),
                  ),
                  SizedBox(height: 18),

                  // Calculate button
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _calculate,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _navy,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        textStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      child: Text("Calculate"),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 26),

          // Result row
          if (calculated)
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                children: [
                  Expanded(
                    child: _ResultCard(icon: Icons.access_time, value: "$totalTime", label: "Minutes"),
                  ),
                  SizedBox(width: 10),
                  Expanded(
                    child: _ResultCard(icon: Icons.directions_subway_filled, value: "$numStations", label: "Stations"),
                  ),
                ],
              ),
            ),
          if (calculated) SizedBox(height: 18),

          // Payment box
          if (calculated)
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 10),
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.all(18),
                decoration: BoxDecoration(color: cardColor, borderRadius: BorderRadius.circular(16)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "The amount to be paid...",
                      style: TextStyle(color: textColor, fontWeight: FontWeight.w400, fontSize: 16),
                    ),
                    SizedBox(height: 5),
                    Text(
                      "${(fare * numPeople).toStringAsFixed(0)} EGP",
                      style: TextStyle(color: textColor, fontWeight: FontWeight.bold, fontSize: 26),
                    ),
                  ],
                ),
              ),
            ),
          SizedBox(height: 30),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: _navy,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white70,
        currentIndex: _selectedIndex,
        showUnselectedLabels: true,
        onTap: _onBottomNavTap,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.menu), label: 'Settings'),
          BottomNavigationBarItem(icon: Icon(Icons.confirmation_number_outlined), label: 'Ticket Price'),
          BottomNavigationBarItem(icon: Icon(Icons.alt_route), label: 'Metro Lines'),
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
        ],
      ),
    );
  }

  InputDecoration _inputDecoration(String hint, bool isDark) {
    return InputDecoration(
      filled: true,
      fillColor: isDark ? Colors.grey[900] : Color(0xFFF6F7F8),
      hintText: hint,
      hintStyle: TextStyle(
        fontWeight: FontWeight.normal,
        color: isDark ? Colors.white70 : Colors.grey[600],
      ),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
      contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 16),
    );
  }
}

class _ResultCard extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;

  const _ResultCard({required this.icon, required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = Theme.of(context).textTheme.bodyLarge?.color ?? (isDark ? Colors.white : Colors.black);
    final cardColor = Theme.of(context).cardColor;

    return Container(
      height: 60,
      decoration: BoxDecoration(color: cardColor, borderRadius: BorderRadius.circular(13)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: textColor, size: 26),
          SizedBox(width: 8),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(value, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: textColor)),
              Text(label, style: TextStyle(color: textColor, fontWeight: FontWeight.w400, fontSize: 14)),
            ],
          ),
        ],
      ),
    );
  }
}