import 'package:flutter/material.dart';
import 'package:metrozzz/screens/calculate_fare_page.dart';
import 'package:metrozzz/screens/home_page.dart';
import 'package:metrozzz/screens/journey_preview_page.dart';
import 'package:metrozzz/screens/login_page.dart';
import 'package:metrozzz/screens/metro_lines_page.dart';
import 'package:metrozzz/screens/register_page.dart';
import 'package:metrozzz/screens/settings_page.dart'; // typo: should this be 'settings_page.dart'?
import 'package:metrozzz/welcome_page.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

// Your Supabase credentials
const supabaseUrl = 'https://kfsextmdrxrfaihzqyoi.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imtmc2V4dG1kcnhyZmFpaHpxeW9pIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU4NzA5MDEsImV4cCI6MjA2MTQ0NjkwMX0._lzJKN3EC_d0r9fY90pbTthckJkIPWNZDZV5EwFW9sc';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  final prefs = await SharedPreferences.getInstance();
  final savedTheme = prefs.getString('theme') ?? 'light';
  final savedLang = prefs.getString('language') ?? 'en';

  runApp(MetroNavigatorApp(
    initialTheme: savedTheme == 'dark' ? ThemeMode.dark : ThemeMode.light,
    initialLocale: Locale(savedLang),
  ));
}

class MetroNavigatorApp extends StatefulWidget {
  final ThemeMode initialTheme;
  final Locale initialLocale;

  MetroNavigatorApp({required this.initialTheme, required this.initialLocale});

  @override
  _MetroNavigatorAppState createState() => _MetroNavigatorAppState();
}

class _MetroNavigatorAppState extends State<MetroNavigatorApp> {
  late ThemeMode _themeMode;
  late Locale _locale;

  @override
  void initState() {
    super.initState();
    _themeMode = widget.initialTheme;
    _locale = widget.initialLocale;
  }

  void _changeTheme(ThemeMode mode) {
    setState(() => _themeMode = mode);
  }

  void _changeLocale(Locale locale) {
    setState(() => _locale = locale);
  }

  // === custom dark theme ===
  final ThemeData myDarkTheme = ThemeData.dark().copyWith(
    scaffoldBackgroundColor: Color(0xFF181C24),
    primaryColor: Color(0xFF1A1749),
    appBarTheme: AppBarTheme(
      backgroundColor: Color(0xFF1A1749),
      foregroundColor: Colors.white,
      iconTheme: IconThemeData(color: Colors.white),
      titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
    ),
    brightness: Brightness.dark,
    textTheme: ThemeData.dark().textTheme.apply(
      bodyColor: Colors.white,
      displayColor: Colors.white,
    ),
    iconTheme: IconThemeData(color: Colors.white),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: Color(0xFF1A1749),
      selectedItemColor: Colors.white,
      unselectedItemColor: Colors.white70,
    ),
    cardColor: Color(0xFF23263A),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Color(0xFF23263A),
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Colors.white12),
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Color(0xFF5A54EA)),
      ),
      labelStyle: TextStyle(color: Colors.white),
      hintStyle: TextStyle(color: Colors.white70),
    ),
    // You can add more theme customizations here!
  );

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Metrozz',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.light().copyWith(
        primaryColor: Color(0xFF1A1749),
        scaffoldBackgroundColor: Color(0xFFF6F7F8),
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Color(0xFF1A1749),
          iconTheme: IconThemeData(color: Color(0xFF1A1749)),
          titleTextStyle: TextStyle(color: Color(0xFF1A1749), fontSize: 20),
        ),
        bottomNavigationBarTheme: BottomNavigationBarThemeData(
          backgroundColor: Color(0xFF1A1749),
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.white70,
        ),
      ),
      darkTheme: myDarkTheme,
      themeMode: _themeMode,
      locale: _locale,
      supportedLocales: [Locale('en'), Locale('ar')],
      home: WelcomePage(),
      routes: {
        '/register': (context) => RegisterPage(),
        '/login': (context) => LoginPage(),
        '/homePage': (context) => HomePage(),
        '/settings': (context) => SettingsPage(
          onThemeChange: _changeTheme,
          onLocaleChange: _changeLocale,
        ),
        '/metroLines':(context) => MetroLinesPage(),
        '/ticketPrice': (context) => CalculateFarePage(),
        '/preview': (context) => JourneyPreviewPage(
          startStation: 'helwan', // dummy values for now
          endStation: 'maadi',
        ),
      },
    );
  }
}