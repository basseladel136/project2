//State Design Pattern
abstract class UserState {
  String getStateName();
}

class AtStationState implements UserState {
  @override
  String getStateName() => 'At Station';
}

class OnTrainState implements UserState {
  @override
  String getStateName() => 'On Train';
}

class ArrivedState implements UserState {
  @override
  String getStateName() => 'Arrived';
}