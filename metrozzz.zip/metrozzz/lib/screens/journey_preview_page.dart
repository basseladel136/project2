import 'package:flutter/material.dart';
import '../models/station.dart';
import '../services/station_service.dart';
import 'journey_progress_page.dart';

class JourneyPreviewPage extends StatefulWidget {
  final String startStation;
  final String endStation;

  JourneyPreviewPage({required this.startStation, required this.endStation});

  @override
  _JourneyPreviewPageState createState() => _JourneyPreviewPageState();
}

class _JourneyPreviewPageState extends State<JourneyPreviewPage> {
  List<Station> journeyStations = [];
  double fare = 0.0;
  bool isLoading = true;

  Color get _navy => const Color(0xFF1A1749);
  final Color _darkBackground = const Color(0xFF121212);
  final Color _cardBackground = const Color(0xFF1E1E1E);
  final Color _borderColor = const Color(0xFF444444);

  @override
  void initState() {
    super.initState();
    _loadJourney();
  }

  Future<void> _loadJourney() async {
    try {
      final service = StationService();
      journeyStations = await service.fetchJourneyStations(widget.startStation, widget.endStation);
      if (journeyStations.length <= 9) {
        fare = 8.0;
      } else if (journeyStations.length <= 16) {
        fare = 10.0;
      } else if (journeyStations.length <= 23) {
        fare = 15.0;
      } else {
        fare = 20.0;
      }
      setState(() => isLoading = false);
    } catch (e) {
      print("Error loading journey: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load journey')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    // Dynamically assign colors based on theme
    final bgColor = isDark ? Color(0xFF121212) : Colors.white;
    final cardBgColor = isDark ? Color(0xFF1E1E1E) : Colors.white;
    final borderColor = isDark ? Color(0xFF444444) : Colors.grey.shade300;
    final textColor = isDark ? Colors.white : Colors.black;
    final textSecondaryColor = isDark ? Colors.white70 : Colors.black54;
    final navyColor = const Color(0xFF1A1749);

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        title: Text(
          '${widget.startStation} To ${widget.endStation}',

        ),
        backgroundColor: isDark ? navyColor: Colors.white,
        elevation: 0,
        iconTheme: IconThemeData(color: textColor),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(navyColor)))
          : Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _infoCard(
                  Icons.access_time,
                  'Time',
                  '${journeyStations.length * 2} Minute',
                  cardBgColor,
                  borderColor,
                  textColor,
                  textSecondaryColor,
                  navyColor,
                ),
                _infoCard(
                  Icons.train,
                  'Stations',
                  '${journeyStations.length}',
                  cardBgColor,
                  borderColor,
                  textColor,
                  textSecondaryColor,
                  navyColor,
                ),
                _infoCard(
                  Icons.money,
                  'Price',
                  '${fare.toStringAsFixed(0)} EGP',
                  cardBgColor,
                  borderColor,
                  textColor,
                  textSecondaryColor,
                  navyColor,
                ),
              ],
            ),
            SizedBox(height: 20),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: cardBgColor,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: borderColor),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Trip description',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: textColor,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Take the first line (Marg direction)',
                    style: TextStyle(color: textSecondaryColor),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: cardBgColor,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: borderColor),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '🚇 Metro route',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: textColor,
                        ),
                      ),
                      Icon(Icons.fullscreen, color: textSecondaryColor),
                    ],
                  ),
                  Divider(color: textSecondaryColor),
                  // You can add custom lines or path representation here if needed
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: journeyStations.length,
                itemBuilder: (context, index) {
                  final station = journeyStations[index];
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 14,
                          height: 14,
                          decoration: BoxDecoration(
                            color: navyColor,
                            shape: BoxShape.circle,
                          ),
                        ),
                        if (index < journeyStations.length - 1)
                          Container(
                            height: 30,
                            width: 2,
                            color: navyColor,
                          ),
                      ],
                    ),
                    title: Text(
                      station.name,
                      style: TextStyle(color: textColor),
                    ),
                    trailing: index == journeyStations.length - 1
                        ? Icon(Icons.check_circle, color: Colors.green, size: 20)
                        : null,
                  );
                },
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) =>
                        JourneyProgressPage(journeyStations: journeyStations),
                  ),
                );
              },
              child: Text('START JOURNEY'),
              style: ElevatedButton.styleFrom(
                backgroundColor: navyColor,
                foregroundColor: Colors.white,
                minimumSize: Size(double.infinity, 48),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoCard(
      IconData icon,
      String label,
      String value,
      Color cardBgColor,
      Color borderColor,
      Color textColor,
      Color textSecondaryColor,
      Color navyColor,
      ) {
    return Container(
      width: 100, // Adjust this width to fit your design
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: cardBgColor,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: borderColor),
      ),
      child: Column(
        children: [
          Icon(icon, color: textSecondaryColor, size: 24),
          SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(fontWeight: FontWeight.bold, color: textSecondaryColor),
          ),
          SizedBox(height: 4),
          Text(value, style: TextStyle(color: textColor)),
        ],
      ),
    );
  }
}