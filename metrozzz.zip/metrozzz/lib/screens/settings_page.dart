import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsPage extends StatefulWidget {
  final Function(Locale) onLocaleChange;
  final Function(ThemeMode) onThemeChange;

  SettingsPage({
    required this.onLocaleChange,
    required this.onThemeChange,
    Key? key,
  }) : super(key: key);

  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  String selectedLanguage = 'en';
  String selectedTheme = 'light';

  final Color navy = const Color(0xFF1A1749);

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      selectedLanguage = prefs.getString('language') ?? 'en';
      selectedTheme = prefs.getString('theme') ?? 'light';
    });
  }

  Future<void> _updateLanguage(String langCode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', langCode);
    setState(() => selectedLanguage = langCode);
    widget.onLocaleChange(Locale(langCode));
  }

  Future<void> _updateTheme(String themeMode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('theme', themeMode);
    setState(() => selectedTheme = themeMode);
    widget.onThemeChange(themeMode == 'dark' ? ThemeMode.dark : ThemeMode.light);
  }

  int _selectedIndex = 0;

  void _onBottomNavTap(int index) {
    setState(() => _selectedIndex = index);
    switch (index) {
      case 0:
      // Already on Settings
        break;
      case 1:
        Navigator.pushReplacementNamed(context, '/ticketPrice');
        break;
      case 2:
        Navigator.pushReplacementNamed(context, '/metroLines');
        break;
      case 3:
        Navigator.pushReplacementNamed(context, '/homePage');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = Theme.of(context).textTheme.bodyLarge?.color ?? (isDark ? Colors.white : Colors.black);

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          // Logo header/top image
          SizedBox(
            height: 260,
            child: Image.asset(
              'assets/images/metro.jpg', // Change to your asset path
              fit: BoxFit.cover,
              width: double.infinity,
            ),
          ),
          SizedBox(height: 36),

          // Language and Theme settings
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Change Language",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: textColor),
                ),
                SizedBox(height: 2),
                DropdownButtonFormField<String>(
                  value: selectedLanguage,
                  dropdownColor: isDark ? navy : Colors.white,
                  decoration: _fieldDecoration(isDark: isDark),
                  style: TextStyle(color: textColor),
                  items: [
                    DropdownMenuItem(value: 'en', child: Text('English', style: TextStyle(color: textColor))),
                    DropdownMenuItem(value: 'ar', child: Text('Arabic', style: TextStyle(color: textColor))),
                  ],
                  onChanged: (val) => _updateLanguage(val!),
                  isExpanded: true,
                ),
                SizedBox(height: 12),
                Divider(thickness: 1, height: 1, color: isDark ? Colors.white12 : Colors.grey[300]),

                SizedBox(height: 18),

                Text(
                  "Change Theme",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: textColor),
                ),
                SizedBox(height: 2),
                DropdownButtonFormField<String>(
                  value: selectedTheme,
                  dropdownColor: isDark ? navy : Colors.white,
                  decoration: _fieldDecoration(isDark: isDark),
                  style: TextStyle(color: textColor),
                  items: [
                    DropdownMenuItem(value: 'light', child: Text('Light', style: TextStyle(color: textColor))),
                    DropdownMenuItem(value: 'dark', child: Text('Dark', style: TextStyle(color: textColor))),
                  ],
                  onChanged: (val) => _updateTheme(val!),
                  isExpanded: true,
                ),
                SizedBox(height: 12),
                Divider(thickness: 1, height: 1, color: isDark ? Colors.white12 : Colors.grey[300]),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: navy,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white70,
        currentIndex: _selectedIndex,
        showUnselectedLabels: true,
        onTap: _onBottomNavTap,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.menu),
            label: 'Settings',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.confirmation_number_outlined),
            label: 'Ticket Price',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.alt_route),
            label: 'Metro Lines',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
        ],
      ),
    );
  }

  InputDecoration _fieldDecoration({required bool isDark}) => InputDecoration(
    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 18),
    filled: true,
    fillColor: isDark ? navy.withOpacity(0.7) : Color(0xFFF6F7F8),
    enabledBorder: UnderlineInputBorder(
      borderSide: BorderSide(color: isDark ? Colors.white12 : Colors.grey[300]!),
    ),
    focusedBorder: UnderlineInputBorder(
      borderSide: BorderSide(color: navy),
    ),
  );
}