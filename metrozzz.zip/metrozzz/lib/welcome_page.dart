import 'package:flutter/material.dart';

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Top image from assets
          SizedBox(
            height: 320,
            child: Image.asset(
              'assets/images/metro.jpg', // <-- Use your asset path
              fit: BoxFit.cover,
              width: double.infinity,
            ),
          ),
          const SizedBox(height: 64),
          // Sign Up Button
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 48.0),
            child: ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/register');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF1A1749),
                foregroundColor: Colors.white,
                minimumSize: const Size.fromHeight(56),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(32),
                ),
                elevation: 2,
              ),
              child: const Text(
                "Sign Up",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          // Login Button (Outlined)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 48.0),
            child: OutlinedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/login'); // this works if the route exists
              },
              style: OutlinedButton.styleFrom(
                side: const BorderSide(
                  color: Color(0xFF1A1749),
                  width: 1.5,
                ),
                foregroundColor: const Color(0xFF1A1749),
                minimumSize: const Size.fromHeight(56),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(32),
                ),
              ),
              child: const Text(
                "Login",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                  color: Color(0xFF1A1749),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}