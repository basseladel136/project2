class NotificationManager {
  // Singleton
  static final NotificationManager _instance = NotificationManager._internal();

  factory NotificationManager() => _instance;

  NotificationManager._internal();

  // Observer: List of callback functions
  final List<void Function(String)> _listeners = [];

  void subscribe(void Function(String) listener) {
    _listeners.add(listener);
  }

  void unsubscribe(void Function(String) listener) {
    _listeners.remove(listener);
  }

  void notify(String message) {
    for (var listener in _listeners) {
      listener(message);
    }
  }
}
