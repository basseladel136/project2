import 'package:another_flushbar/flushbar.dart';
import 'package:flutter/material.dart';
import '../models/station.dart';
import '../models/user_state.dart';
import '../services/notification_manager.dart';
import 'home_page.dart';

class JourneyProgressPage extends StatefulWidget {
  final List<Station> journeyStations;

  JourneyProgressPage({required this.journeyStations});

  @override
  _JourneyProgressPageState createState() => _JourneyProgressPageState();
}

class _JourneyProgressPageState extends State<JourneyProgressPage> {
  int currentIndex = 0;
  UserState journeyState = AtStationState();

  @override
  void initState() {
    super.initState();
    NotificationManager().subscribe(_handleNotification);
  }

  @override
  void dispose() {
    NotificationManager().unsubscribe(_handleNotification);
    super.dispose();
  }

  void _handleNotification(String message) {
    Flushbar(
      message: message,
      duration: Duration(seconds: 2),
      backgroundColor: Colors.indigo,
      margin: EdgeInsets.all(8),
      borderRadius: BorderRadius.circular(8),
      flushbarPosition: FlushbarPosition.TOP,
    ).show(context);
  }

  void _nextStation() {
    if (currentIndex < widget.journeyStations.length - 1) {
      setState(() {
        currentIndex++;

        if (currentIndex == widget.journeyStations.length - 1) {
          journeyState = ArrivedState();
          NotificationManager().notify("🎉 You've arrived at your destination!");
        } else {
          journeyState = OnTrainState();
          NotificationManager().notify("🚉 Now at ${widget.journeyStations[currentIndex].name}");
        }
      });
    }
  }
  Color get _navy => const Color(0xFF1A1749);
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    // Colors adapting to theme
    final bgColor = isDark ? Color(0xFF121212) : Colors.white;
    final cardBgColor = isDark ? Color(0xFF1E1E1E) : Colors.grey[300]!;
    final borderRadius = BorderRadius.circular(8);
    final textColor = isDark ? Colors.white : Colors.black;
    final secondaryTextColor = isDark ? Colors.white70 : Colors.black54;
    final navyColor = const Color(0xFF1A1749);

    final current = widget.journeyStations[currentIndex];
    final stationsLeft = widget.journeyStations.length - currentIndex - 1;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        title: Text(
          'Journey Progress',
          style: TextStyle(color: textColor),
        ),
        backgroundColor: isDark ? navyColor : Colors.white,
        elevation: 0,
        iconTheme: IconThemeData(color: textColor),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _infoBox('Current Station:', current.name, cardBgColor, textColor, borderRadius),
            SizedBox(height: 10),
            _infoBox('Stations Left:', '$stationsLeft', cardBgColor, textColor, borderRadius),
            SizedBox(height: 10),
            _infoBox('Journey State:', journeyState.getStateName(), cardBgColor, textColor, borderRadius),
            SizedBox(height: 20),
            Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: cardBgColor,
                borderRadius: borderRadius,
              ),
              height: 200, // Keep this to reserve space for ListView
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '🛤 The Metro Itinerary',
                    style: TextStyle(fontWeight: FontWeight.bold, color: navyColor),
                  ),
                  Divider(color: navyColor),
                  Expanded(
                    child: ListView(
                      children: widget.journeyStations.map((s) {
                        final isCurrent = s == current;
                        return ListTile(
                          leading: Icon(
                            isCurrent ? Icons.train : Icons.circle_outlined,
                            color: isCurrent ? navyColor : secondaryTextColor,
                          ),
                          title: Text(
                            s.name,
                            style: TextStyle(
                              fontWeight: isCurrent ? FontWeight.bold : FontWeight.normal,
                              color: isCurrent ? navyColor : textColor,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: currentIndex == widget.journeyStations.length - 1
                  ? () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                );
              }
                  : _nextStation,
              child: Text(currentIndex == widget.journeyStations.length - 1 ? 'End Journey' : 'Next Station'),
              style: ElevatedButton.styleFrom(
                backgroundColor: navyColor,
                foregroundColor: Colors.white,
                minimumSize: Size(double.infinity, 48),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoBox(String label, String value, Color backgroundColor, Color textColor, BorderRadius borderRadius) {
    final secondaryTextColor = textColor.withOpacity(0.7);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(color: secondaryTextColor)),
        SizedBox(height: 4),
        Container(
          width: double.infinity,
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: backgroundColor,
            borderRadius: borderRadius,
          ),
          child: Text(
            value,
            style: TextStyle(color: textColor),
          ),
        ),
      ],
    );
  }
}