import 'package:another_flushbar/flushbar.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/station.dart';
import '../services/station_service.dart';
import 'journey_preview_page.dart';
import 'metro_lines_page.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final StationService stationService = StationService();

  int? startStationId;
  int? endStationId;
  int _selectedIndex = 3;

  List<Station> allStations = [];
  bool isLoading = true;
  Station? nearestStation;

  final Color _navy = const Color(0xFF1A1749);

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    await _loadAllStations();
    await _determinePositionAndFindNearest();
  }

  Future<void> _loadAllStations() async {
    setState(() => isLoading = true);
    final stations = await stationService.fetchStations();
    setState(() {
      allStations = stations;
      isLoading = false;
    });
  }

  Future<void> _determinePositionAndFindNearest() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        return;
      }

      final position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);

      if (allStations.isEmpty) return;

      Station? nearest;
      double minDistance = double.infinity;

      for (var station in allStations) {
        double distanceInMeters = Geolocator.distanceBetween(
          position.latitude, position.longitude,
          station.latitude, station.longitude,
        );

        if (distanceInMeters < minDistance) {
          minDistance = distanceInMeters;
          nearest = station;
        }
      }

      if (nearest != null) {
        setState(() {
          nearestStation = nearest;
          // startStationId = nearest.id; // <-- Set nearest as start station
        });
      }
    } catch (e) {
      print('Error determining position: $e');
    }
  }

  void _navigateToJourney() {
    if (startStationId != null && endStationId != null && startStationId != endStationId) {
      final startStation = allStations.firstWhere((s) => s.id == startStationId);
      final endStation = allStations.firstWhere((s) => s.id == endStationId);

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => JourneyPreviewPage(
            startStation: startStation.name,
            endStation: endStation.name,
          ),
        ),
      );
    } else {
      Flushbar(
        message: 'Please select different start and end stations',
        duration: Duration(seconds: 2),
        backgroundColor: Colors.red,
        flushbarPosition: FlushbarPosition.TOP,
        margin: EdgeInsets.all(8),
        borderRadius: BorderRadius.circular(8),
      ).show(context);
    }
  }

  Color _getLineColor(String line) {
    switch (line) {
      case '1':
        return Colors.red;
      case '2':
        return Colors.blue;
      case '3':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  void _onBottomNavTap(int index) {
    setState(() => _selectedIndex = index);
    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/settings');
        break;
      case 1:
        Navigator.pushNamed(context, '/ticketPrice');
        break;
      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => MetroLinesPage()),
        );
        break;
      case 3:
      // Already on home
        break;
    }
  }

  Future<void> _openMap(double lat, double lng) async {
    final googleMapsUrl = 'https://www.google.com/maps/search/?api=1&query=$lat,$lng';
    if (await canLaunch(googleMapsUrl)) {
      await launch(googleMapsUrl);
    } else {
      // Show an error if the map cannot be opened.
      Flushbar(
        message: 'Could not open the map.',
        duration: Duration(seconds: 2),
        backgroundColor: Colors.red,
        flushbarPosition: FlushbarPosition.TOP,
        margin: EdgeInsets.all(8),
        borderRadius: BorderRadius.circular(8),
      ).show(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black;
    final scaffoldBg = isDark ? Color(0xFF181C24) : Colors.white;
    final fillColor = isDark ? Color(0xFF23263A) : Colors.white;

    final borderSide = BorderSide(color: _navy, width: 1.3);

    return Scaffold(
      backgroundColor: scaffoldBg,
      body: SafeArea(
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 18, 24, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (nearestStation != null) ...[
                  Text(
                    'Nearest metro station',
                    style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 16),
                  ),
                  SizedBox(height: 8),
                  Container(
                    padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                    decoration: BoxDecoration(
                      color: fillColor,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _navy),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.location_on, color: _navy),
                            SizedBox(width: 8),
                            Text(nearestStation!.name, style: TextStyle(color: textColor, fontSize: 16)),
                          ],
                        ),
                        IconButton(
                          icon: Icon(Icons.map, color: _navy),
                          onPressed: () {
                            _openMap(nearestStation!.latitude, nearestStation!.longitude);
                          },
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 30),
                ],
                Center(
                  child: Column(
                    children: [
                      Text(
                        "Know your trip details",
                        style: TextStyle(
                          color: textColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                      SizedBox(height: 7),
                      Text(
                        'Enter the stations to know the trip details',
                        style: TextStyle(
                          color: textColor.withOpacity(0.7),
                          fontSize: 13,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 30),
                Text('From', style: TextStyle(color: textColor, fontWeight: FontWeight.w500)),
                SizedBox(height: 6),
                DropdownButtonFormField<int>(
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: borderSide,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: borderSide,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    filled: true,
                    fillColor: fillColor,
                    contentPadding: EdgeInsets.symmetric(vertical: 12, horizontal: 14),
                  ),
                  value: startStationId,
                  isExpanded: true,
                  hint: Text(
                    "From",
                    style: TextStyle(fontWeight: FontWeight.normal, color: textColor),
                  ),
                  onChanged: (value) {
                    setState(() => startStationId = value);
                  },
                  dropdownColor: fillColor,
                  style: TextStyle(color: textColor),
                  items: allStations
                      .map(
                        (station) => DropdownMenuItem<int>(
                      value: station.id,
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 10,
                            backgroundColor: _getLineColor(station.line),
                            child: Text(
                              station.line,
                              style: TextStyle(color: Colors.white, fontSize: 12),
                            ),
                          ),
                          SizedBox(width: 8),
                          Text('${station.name} ', style: TextStyle(color: textColor)),
                        ],
                      ),
                    ),
                  )
                      .toList(),
                ),
                SizedBox(height: 16),
                Text('To', style: TextStyle(color: textColor, fontWeight: FontWeight.w500)),
                SizedBox(height: 6),
                DropdownButtonFormField<int>(
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: borderSide,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: borderSide,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    filled: true,
                    fillColor: fillColor,
                    contentPadding: EdgeInsets.symmetric(vertical: 12, horizontal: 14),
                  ),
                  value: endStationId,
                  isExpanded: true,
                  hint: Text(
                    "To",
                    style: TextStyle(fontWeight: FontWeight.normal, color: textColor),
                  ),
                  onChanged: (value) {
                    setState(() => endStationId = value);
                  },
                  dropdownColor: fillColor,
                  style: TextStyle(color: textColor),
                  items: allStations
                      .map(
                        (station) => DropdownMenuItem<int>(
                      value: station.id,
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 10,
                            backgroundColor: _getLineColor(station.line),
                            child: Text(
                              station.line,
                              style: TextStyle(color: Colors.white, fontSize: 12),
                            ),
                          ),
                          SizedBox(width: 8),
                          Text('${station.name} ', style: TextStyle(color: textColor)),
                        ],
                      ),
                    ),
                  )
                      .toList(),
                ),
                SizedBox(height: 28),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: _navigateToJourney,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _navy,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      textStyle: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    child: Text("Details"),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: _navy,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white70,
        currentIndex: _selectedIndex,
        showUnselectedLabels: true,
        onTap: _onBottomNavTap,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.menu),
            label: 'Settings',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.confirmation_number_outlined),
            label: 'Ticket Price',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.alt_route),
            label: 'Metro Lines',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
        ],
      ),
    );
  }
}