import 'dart:collection'; // For Queue
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/station.dart';

class StationService {
  // Singleton pattern
  static final StationService _instance = StationService._internal();
  factory StationService() => _instance;
  StationService._internal();

  final SupabaseClient client = Supabase.instance.client;

  Future<List<Station>> fetchStationsByLine(String lineName) async {
    final lineId = _lineNameToId(lineName);

    final response = await client
        .from('stations')
        .select()
        .eq('line_id', lineId)
        .order('station_order');

    return (response as List)
        .map((stationJson) => Station.fromJson(stationJson))
        .toList();
  }

  Future<List<Station>> fetchGroupedStationsByLine(String lineName) async {
    final lineId = _lineNameToId(lineName);

    final response = await client
        .from('stations')
        .select()
        .eq('line_id', lineId)
        .order('station_order');

    final stations = (response as List).map((s) => Station.fromJson(s)).toList();

    // Deduplicate stations by name: this can handle some interchange duplicates
    final Map<String, Station> uniqueByName = {};
    for (var station in stations) {
      if (!uniqueByName.containsKey(station.name)) {
        uniqueByName[station.name] = station;
      }
    }
    return uniqueByName.values.toList();
  }

  int _lineNameToId(String lineName) {
    switch (lineName.toLowerCase()) {
      case 'line 1':
        return 1;
      case 'line 2':
        return 2;
      case 'line 3':
        return 3;
      default:
        throw Exception('Invalid line name: $lineName');
    }
  }

  Future<List<Station>> fetchStations() async {
    final response = await client.from('stations').select().order('station_order');

    return (response as List)
        .map((stationJson) => Station.fromJson(stationJson))
        .toList();
  }

  /// Find journey path between stations by names (supports interchanges).
  /// Returns a list of Station representing the path.
  Future<List<Station>> fetchJourneyStations(String start, String end) async {
    final response = await client.from('stations').select().order('station_order');

    final stations = (response as List).map((s) => Station.fromJson(s)).toList();

    // Map stations by lowercase name to list of stations (for interchanges)
    Map<String, List<Station>> nameToStations = {};
    for (var station in stations) {
      nameToStations.putIfAbsent(station.name.toLowerCase(), () => []).add(station);
    }

    final startOptions = nameToStations[start.toLowerCase()] ?? [];
    final endOptions = nameToStations[end.toLowerCase()] ?? [];

    if (startOptions.isEmpty || endOptions.isEmpty) {
      throw Exception('Start or end station not found.');
    }

    Set<String> visited = {};
    Queue<List<Station>> queue = Queue();

    // Enqueue paths starting at each start station variant
    for (var startStation in startOptions) {
      queue.add([startStation]);
      visited.add('${startStation.name}-${startStation.line}');
    }

    while (queue.isNotEmpty) {
      final path = queue.removeFirst();
      final currentStation = path.last;

      // Check if current station matches any end station option on same line & name
      if (endOptions.any((s) => s.name == currentStation.name && s.line == currentStation.line)) {
        return path;
      }

      // Explore neighboring stations on current line
      final stationsOnLine = stations.where((s) => s.line == currentStation.line).toList()
        ..sort((a, b) => a.order.compareTo(b.order));

      final currentIndex = stationsOnLine.indexWhere((s) => s.id == currentStation.id);

      // Backward station
      if (currentIndex > 0) {
        final prevStation = stationsOnLine[currentIndex - 1];
        final key = '${prevStation.name}-${prevStation.line}';
        if (!visited.contains(key)) {
          visited.add(key);
          queue.add([...path, prevStation]);
        }
      }

      // Forward station
      if (currentIndex < stationsOnLine.length - 1) {
        final nextStation = stationsOnLine[currentIndex + 1];
        final key = '${nextStation.name}-${nextStation.line}';
        if (!visited.contains(key)) {
          visited.add(key);
          queue.add([...path, nextStation]);
        }
      }

      // Transfers at the same station name to other lines
      final transferStations = nameToStations[currentStation.name.toLowerCase()] ?? [];
      for (var transfer in transferStations) {
        final key = '${transfer.name}-${transfer.line}';
        if (transfer.line != currentStation.line && !visited.contains(key)) {
          visited.add(key);
          queue.add([...path, transfer]);
        }
      }
    }

    throw Exception('No valid path found between $start and $end');
  }

  /// Similar pathfinder using station IDs instead of names.
  Future<List<Station>> fetchJourneyStationsById(int startId, int endId) async {
    final response = await client.from('stations').select().order('station_order');
    final stations = (response as List).map((s) => Station.fromJson(s)).toList();

    // Map station ids to station objects
    Map<int, Station> idToStation = {for (var s in stations) s.id: s};

    final startStation = idToStation[startId];
    final endStation = idToStation[endId];

    if (startStation == null || endStation == null) {
      throw Exception('Start or end station not found by IDs.');
    }

    // Map station names (lowercase) to list of station variants for transfers
    Map<String, List<Station>> nameToStations = {};
    for (var s in stations) {
      nameToStations.putIfAbsent(s.name.toLowerCase(), () => []).add(s);
    }

    Set<String> visited = {};
    Queue<List<Station>> queue = Queue();

    // Start BFS paths from the starting station
    queue.add([startStation]);
    visited.add('${startStation.name}-${startStation.line}');

    while (queue.isNotEmpty) {
      final path = queue.removeFirst();
      final currentStation = path.last;

      // Check if current station is the destination station by id
      if (currentStation.id == endId) {
        return path;
      }

      // Stations on the same line
      final lineStations = stations.where((s) => s.line == currentStation.line).toList()
        ..sort((a, b) => a.order.compareTo(b.order));

      final currentIndex = lineStations.indexWhere((s) => s.id == currentStation.id);

      // Backward neighbor
      if (currentIndex > 0) {
        final backStation = lineStations[currentIndex - 1];
        final key = '${backStation.name}-${backStation.line}';
        if (!visited.contains(key)) {
          visited.add(key);
          queue.add([...path, backStation]);
        }
      }

      // Forward neighbor
      if (currentIndex < lineStations.length - 1) {
        final forwardStation = lineStations[currentIndex + 1];
        final key = '${forwardStation.name}-${forwardStation.line}';
        if (!visited.contains(key)) {
          visited.add(key);
          queue.add([...path, forwardStation]);
        }
      }

      // Transfers (other lines at same station name)
      final transfers = nameToStations[currentStation.name.toLowerCase()] ?? [];
      for (var transfer in transfers) {
        final key = '${transfer.name}-${transfer.line}';
        if (transfer.line != currentStation.line && !visited.contains(key)) {
          visited.add(key);
          queue.add([...path, transfer]);
        }
      }
    }

    throw Exception('No valid path found between $startId and $endId');
  }
}