import 'package:flutter/material.dart';
import '../models/station.dart';
import '../services/station_service.dart';

class MetroLinesPage extends StatefulWidget {
  @override
  _MetroLinesPageState createState() => _MetroLinesPageState();
}

class _MetroLinesPageState extends State<MetroLinesPage> {
  String? selectedLine;
  List<Station> stations = [];
  bool isLoading = false;
  int _selectedIndex = 1; // Metro Lines tab index

  // For display → database line mapping
  final Map<String, String> lineNameMap = {
    "First Line": "Line 1",
    "Second Line": "Line 2",
    "Third Line": "Line 3"
  };
  final List<String> displayLines = ["First Line", "Second Line", "Third Line"];

  @override
  void initState() {
    super.initState();
    selectedLine = displayLines[0];
    _loadStationsForLine(selectedLine!);
  }

  Future<void> _loadStationsForLine(String displayLine) async {
    setState(() => isLoading = true);
    try {
      final dbLine = lineNameMap[displayLine]!;
      final result = await StationService().fetchStationsByLine(dbLine);
      setState(() {
        stations = result;
        isLoading = false;
      });
    } catch (e) {
      setState(() => isLoading = false);
      // Optionally handle error (show a snackbar)
    }
  }

  void _onBottomNavTap(int idx) {
    setState(() => _selectedIndex = idx);
    switch (idx) {
      case 0: // Home
        Navigator.pushReplacementNamed(context, '/homePage');
        break;
      case 1: // Metro Lines (current page)
        break;
      case 2: // Ticket price
        Navigator.pushReplacementNamed(context, '/ticketPrice');
        break;
      case 3: // Settings
        Navigator.pushReplacementNamed(context, '/settings');
        break;
    }
  }

  Color get _navy => const Color(0xFF1A1749);

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final bg = theme.scaffoldBackgroundColor;
    final cardBg = theme.cardColor;
    final borderColor = theme.dividerColor;
    final textColor = theme.textTheme.bodyLarge?.color ?? (isDark ? Colors.white : Colors.black);
    final textSecondaryColor = theme.textTheme.bodyMedium?.color?.withOpacity(0.7) ?? (isDark ? Colors.white70 : Colors.black54);
    final bottomNavBg = _navy; // Navy color stays constant

    return Scaffold(
      backgroundColor: bg,
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.only(left: 18, right: 18, top: 8, bottom: 2),
            child: Text(
              "Map of the metro",
              style: TextStyle(
                color: textColor,
                fontWeight: FontWeight.w600,
                fontSize: 16,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14.0, vertical: 0),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(13),
              child: GestureDetector(
                onTap: () {
                  Navigator.pushNamed(context, '/imageDetail');
                },
                child: Image.asset(
                  "assets/images/new-map8.jpg",
                  fit: BoxFit.cover,
                  height: 90,
                  width: double.infinity,
                ),
              ),
            ),
          ),
          SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: cardBg,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: borderColor),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Know metro and capital train lines",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: textColor,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    "Choose the line and we will tell you all the stations",
                    style: TextStyle(
                      fontSize: 13,
                      color: textSecondaryColor,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 15),
                  DropdownButtonFormField<String>(
                    value: selectedLine,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: bg,
                      hintText: 'Choose Line',
                      hintStyle: TextStyle(color: textSecondaryColor),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(color: borderColor),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(color: borderColor),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(color: bottomNavBg),
                      ),
                      contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 18),
                    ),
                    dropdownColor: cardBg,
                    style: TextStyle(color: textColor),
                    items: displayLines
                        .map(
                          (line) => DropdownMenuItem(
                        value: line,
                        child: Text(line, style: TextStyle(color: textColor)),
                      ),
                    )
                        .toList(),
                    onChanged: (v) {
                      setState(() {
                        selectedLine = v!;
                        _loadStationsForLine(selectedLine!);
                      });
                    },
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(horizontal: 0, vertical: 18),
              decoration: BoxDecoration(
                color: cardBg,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: borderColor),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 20.0, right: 6, bottom: 12),
                    child: Row(
                      children: [
                        Text(
                          "Metro route",
                          style: TextStyle(
                            color: textColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        Spacer(),
                        // You can add buttons here if needed
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 10, right: 10),
                    child: isLoading
                        ? Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 28.0),
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(bottomNavBg),
                        ),
                      ),
                    )
                        : _MetroVerticalLineList(
                      stations: stations,
                      lineColor: textColor,
                      textColor: textColor,
                      isDarkMode: isDark,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: bottomNavBg,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white,
        currentIndex: _selectedIndex,
        showUnselectedLabels: true,
        onTap: _onBottomNavTap,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.alt_route),
            label: 'Metro Lines',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.confirmation_number_outlined),
            label: 'Ticket Price',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.menu),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}

class _MetroVerticalLineList extends StatelessWidget {
  final List<Station> stations;
  final Color lineColor;
  final Color textColor;
  final bool isDarkMode;

  const _MetroVerticalLineList({
    required this.stations,
    required this.lineColor,
    required this.textColor,
    this.isDarkMode = false,
  });

  @override
  Widget build(BuildContext context) {
    if (stations.isEmpty) {
      return Padding(
        padding: const EdgeInsets.all(18.0),
        child: Text(
          'No stations found.',
          style: TextStyle(color: isDarkMode ? Colors.white70 : Colors.black54),
        ),
      );
    }

    return Column(
      children: List.generate(stations.length, (i) {
        final isFirst = i == 0;
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Vertical line and station circles
            Column(
              children: [
                Container(
                  width: 24,
                  child: Column(
                    children: [
                      if (!isFirst)
                        Container(
                          width: 3,
                          height: 17,
                          color: lineColor,
                        ),
                      Container(
                        width: 16,
                        height: 16,
                        decoration: BoxDecoration(
                          color: isFirst ? lineColor : Colors.transparent,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: lineColor,
                            width: 3,
                          ),
                        ),
                      ),
                      if (i != stations.length - 1)
                        Container(
                          width: 3,
                          height: 17,
                          color: lineColor,
                        ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(width: 5),
            Container(
              padding: EdgeInsets.symmetric(vertical: 4),
              width: MediaQuery.of(context).size.width - 110,
              child: Text(
                stations[i].name,
                style: TextStyle(
                  color: textColor,
                  fontWeight: isFirst ? FontWeight.bold : FontWeight.normal,
                  fontSize: isFirst ? 17 : 15,
                ),
              ),
            ),
          ],
        );
      }),
    );
  }
}

class ImageDetailPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Center(
          child: InteractiveViewer(
            child: Image.asset(
              'assets/images/new-map8.jpg',
              fit: BoxFit.contain,
              width: double.infinity,
              height: double.infinity,
            ),
          ),
        ),
      ),
    );
  }
}