import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:another_flushbar/flushbar.dart';
import 'login_page.dart';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmController = TextEditingController();
  bool _isLoading = false;
  bool _rememberMe = false;

  Future<void> _register() async {
    setState(() {
      _isLoading = true;
    });

    if (_passwordController.text != _confirmController.text) {
      Flushbar(
        message: 'Passwords do not match',
        duration: Duration(seconds: 2),
        backgroundColor: Colors.red,
        flushbarPosition: FlushbarPosition.TOP,
        margin: EdgeInsets.all(8),
        borderRadius: BorderRadius.circular(8),
      ).show(context);

      setState(() {
        _isLoading = false;
      });
      return;
    }

    try {
      final response = await Supabase.instance.client.auth.signUp(
        email: _emailController.text,
        password: _passwordController.text,
      );

      if (response.user != null) {
        Flushbar(
          message: 'Sign Up successful!',
          duration: Duration(seconds: 2),
          backgroundColor: Colors.green,
          flushbarPosition: FlushbarPosition.TOP,
          margin: EdgeInsets.all(8),
          borderRadius: BorderRadius.circular(8),
        ).show(context);

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => LoginPage()),
        );
      } else {
        Flushbar(
          message: 'Sign Up failed',
          duration: Duration(seconds: 2),
          backgroundColor: Colors.red,
          flushbarPosition: FlushbarPosition.TOP,
          margin: EdgeInsets.all(8),
          borderRadius: BorderRadius.circular(8),
        ).show(context);
      }
    } on AuthException catch (error) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(error.message)));
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final navy = Color(0xff23235B);

    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 28.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title
              Text(
                'Sign Up',
                style: TextStyle(
                  fontSize: 28,
                  color: navy,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 32),

              // Email Field
              Text(
                'Email Address',
                style: TextStyle(
                  color: navy,
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: 8),
              TextField(
                controller: _emailController,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(vertical: 16, horizontal: 14),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: navy),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: navy, width: 2),
                  ),
                ),
              ),
              SizedBox(height: 18),

              // Password Field
              Text(
                'Create Password',
                style: TextStyle(
                  color: navy,
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: 8),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(vertical: 16, horizontal: 14),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: navy),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: navy, width: 2),
                  ),
                ),
              ),
              SizedBox(height: 18),

              // Confirm Password Field
              Text(
                'Confirm Password',
                style: TextStyle(
                  color: navy,
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: 8),
              TextField(
                controller: _confirmController,
                obscureText: true,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(vertical: 16, horizontal: 14),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: navy),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: navy, width: 2),
                  ),
                ),
              ),
              SizedBox(height: 12),

              Row(
                children: [
                  Checkbox(
                    value: _rememberMe,
                    activeColor: navy,
                    onChanged: (v) {
                      setState(() => _rememberMe = v!);
                    },
                  ),
                  SizedBox(width: 4),
                  Text(
                    'Remember me on this device',
                    style: TextStyle(color: navy, fontSize: 14),
                  )
                ],
              ),
              SizedBox(height: 24),

              // Sign Up button
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _register,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: navy,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                  ),
                  child: _isLoading
                      ? CircularProgressIndicator(
                    valueColor:
                    AlwaysStoppedAnimation<Color>(Colors.white),
                  )
                      : Text('Sign Up', style: TextStyle(fontSize: 18)),
                ),
              ),
              SizedBox(height: 22),
              Center(
                child: TextButton(
                  onPressed: () {
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (_) => LoginPage()));
                  },
                  child: Text(
                    'Already have an account? Login here.',
                    style: TextStyle(color: navy),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}